function X = getpoints;

figure;
[x y] = ywgetpts;
X = [x y];
close(gcf);
